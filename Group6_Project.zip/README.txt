O zip apenas contém os ficheiros de código, os dados necessários para correr o código deverão ser descarregados da seguinte pasta do google drive e colocados na mesma pasta dos ficheiros .py/.ipynb

https://drive.google.com/drive/folders/1vx4mmlMwV-Nb4JGHfiPWgw0OIowkoHOW?usp=sharing

Os ficheiros de script .py/.ipynb devem ser corridos secção a secção(i.e. secção 1. e 2.), sem voltar para trás ou saltar à frente ou não se pode garantir o correcto funcionamento dos mesmos.

Os scripts do trabalho são:

1.Missing data, Visualization and Outlier detection:
	missing_data.py
	features_visualization_outlier_removal.ipynb

2.Clustering:
	features_clustering.ipynb
	Skeletons_clustering.ipynb
	Augmented_data_clustering.ipynb

Auxiliary scripts:
	extract_images.py
	draw_pose.py
	empca.py
	visualization_dimensionality_red_functions.py
	outlier_detection_functions.py
	skeletons_aux_functions.py
	clustering_functions.py
	augmentation_script.py

